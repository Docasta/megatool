ONLY WORKS ON WIN!!!!!!!

If the applications displayed in the interface are not
 on your PC, the buttons that do not open the
 applications will be useless.